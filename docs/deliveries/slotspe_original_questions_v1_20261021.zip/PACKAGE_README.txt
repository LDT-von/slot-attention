SlotSPE original questions experiment package v1
Read docs/research/slotspe_mechanism_protocol_20261021/实验协议与判定.txt and 服务器AI_原八项问题实验.txt.
Default entry: python -B scripts/run_slotspe_problem_experiments.py --plan
No patients/checkpoints included. Actual inputs are existing private server artifacts.
Only --run executes. observe has zero optimizer steps; capacity_train is separate.
63 synthetic tests passed locally. Native server replay and real-data experiments have NOT run.
New source snapshot is uncommitted; base Git commit is provenance only.
Upstream README is excluded from this archive because it contains patient-like example identifiers; vendored executable source is unchanged.
